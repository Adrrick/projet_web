<?php

    include 'pdo.php';

    $keywords = htmlspecialchars($_POST['keywords']);
    $categorie = htmlspecialchars($_POST['categorie']);
    $ville = htmlspecialchars($_POST['ville']);
    $min = htmlspecialchars($_POST['min']);
    $max = htmlspecialchars($_POST['max']);

    # Making sure the user didn't submit nothing, or made mistakes with the numbers
    if (empty($keywords) && empty($categorie) && empty($ville) && empty($min) && empty($max)) {
        header('Location: http://localhost:8080/projet_web/recherche.php');
        exit;
    } elseif (!empty($min)) {
        if ($min < 0 || is_numeric($min) == False) {
            header('Location: http://localhost:8080/projet_web/recherche.php');
            exit;
        }
    } elseif (!empty($max)) {
        if ($max < 0 || is_numeric($max) == False) {
            header('Location: http://localhost:8080/projet_web/recherche.php');
            exit;
        }
    } elseif (!empty($min) && !empty($max)) {
        if (($min < 0 || is_numeric($min) == False) || ($max < 0 || is_numeric($max) == False) || $min > $max || $min == $max) {
            header('Location: http://localhost:8080/projet_web/recherche.php');
            exit;
        }
    }

    # keywords
    if (!empty($keywords) && empty($categorie) && empty($ville) && empty($min) && empty($max)) {
        $requete1 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE titre LIKE '%$keywords%'";
        $query1 = $pdo->prepare($requete1);  
        $query1->execute();
        $results = $query1->fetchAll();
    # categorie  
    } elseif (empty($keywords) && !empty($categorie) && empty($ville) && empty($min) && empty($max)) {
        $requete2 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE categorie LIKE '%$categorie%'";
        $query2 = $pdo->prepare($requete2);  
        $query2->execute();
        $results = $query2->fetchAll();
    # ville
    } elseif (empty($keywords) && empty($categorie) && !empty($ville) && empty($min) && empty($max)) {
        $requete3 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE ville LIKE '%$ville%'";
        $query3 = $pdo->prepare($requete3);      
        $query3->execute();
        $results = $query3->fetchAll();
    # min
    } elseif (empty($keywords) && empty($categorie) && empty($ville) && !empty($min) && empty($max)) {
        $requete4 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE prix >= :min";
        $query4 = $pdo->prepare($requete4);
        $query4->bindParam('min', $min);      
        $query4->execute();
        $results = $query4->fetchAll();
    # max
    } elseif (empty($keywords) && empty($categorie) && empty($ville) && empty($min) && !empty($max)) {
        $requete5 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE prix <= :max";
        $query5 = $pdo->prepare($requete5);
        $query5->bindParam('max', $max);      
        $query5->execute();
        $results = $query5->fetchAll();
    # keywords + categorie
    } elseif (!empty($keywords) && !empty($categorie) && empty($ville) && empty($min) && empty($max)) {
        $requete6 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE titre LIKE '%$keywords%' AND categorie LIKE '%$categorie%'";
        $query6 = $pdo->prepare($requete6);
        $query6->execute();
        $results = $query6->fetchAll();
    # keywords + ville
    } elseif (!empty($keywords) && empty($categorie) && !empty($ville) && empty($min) && empty($max)) {
        $requete7 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE titre LIKE '%$keywords%' AND ville LIKE '%$ville%'";
        $query7 = $pdo->prepare($requete7);
        $query7->execute();
        $results = $query7->fetchAll();
    # keywords + min
    } elseif (!empty($keywords) && empty($categorie) && empty($ville) && !empty($min) && empty($max)) {
        $requete8 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE titre LIKE '%$keywords%' AND prix >= :min";
        $query8 = $pdo->prepare($requete8);
        $query8->bindParam('min', $min);      
        $query8->execute();
        $results = $query8->fetchAll();
    # keywords + max
    } elseif (!empty($keywords) && empty($categorie) && empty($ville) && empty($min) && !empty($max)) {
        $requete9 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE titre LIKE '%$keywords%' AND prix <= :max";
        $query9 = $pdo->prepare($requete9);
        $query9->bindParam('max', $max);      
        $query9->execute();
        $results = $query9->fetchAll();
    #keywords + categorie + ville
    } elseif (!empty($keywords) && !empty($categorie) && !empty($ville) && empty($min) && empty($max)) {
        $requete10 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE titre LIKE '%$keywords%' AND categorie LIKE '%$categorie%' AND ville LIKE '%$ville%'";
        $query10 = $pdo->prepare($requete10);      
        $query10->execute();
        $results = $query10->fetchAll();
    #keywords + categorie + min
    } elseif (!empty($keywords) && !empty($categorie) && empty($ville) && !empty($min) && empty($max)) {
        $requete11 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE titre LIKE '%$keywords%' AND categorie LIKE '%$categorie%' AND prix >= :min";
        $query11 = $pdo->prepare($requete11);
         $query11->bindParam('min', $min);     
        $query11->execute();
        $results = $query11->fetchAll();
    #keywords + categorie + max
    } elseif (!empty($keywords) && !empty($categorie) && empty($ville) && empty($min) && !empty($max)) {
        $requete12 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE titre LIKE '%$keywords%' AND categorie LIKE '%$categorie%' AND prix <= :max";
        $query12 = $pdo->prepare($requete12);
        $query12->bindParam('max', $max);      
        $query12->execute();
        $results = $query12->fetchAll();
    #keywords + categorie + ville + min
    } elseif (!empty($keywords) && !empty($categorie) && !empty($ville) && !empty($min) && empty($max)) {
        $requete13 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE titre LIKE '%$keywords%' AND categorie LIKE '%$categorie%' AND ville LIKE '%$ville%' AND prix >= :min";
        $query13 = $pdo->prepare($requete13);
        $query13->bindParam('min', $min);      
        $query13->execute();
        $results = $query13->fetchAll();
    # keywords + categorie + ville + max
    } elseif (!empty($keywords) && !empty($categorie) && !empty($ville) && empty($min) && !empty($max)) {
        $requete14 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE titre LIKE '%$keywords%' AND categorie LIKE '%$categorie%' AND ville LIKE '%$ville%' AND prix <= :max";
        $query14 = $pdo->prepare($requete14);
        $query14->bindParam('max', $max);      
        $query14->execute();
        $results = $query14->fetchAll();
    # everything
    } elseif (!empty($keywords) && !empty($categorie) && !empty($ville) && !empty($min) && !empty($max)) {
        $requete15 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE titre LIKE '%$keywords%' AND categorie LIKE '%$categorie%' AND ville LIKE '%$ville%' AND prix >= :min AND prix <= :max";
        $query15 = $pdo->prepare($requete15);       
        $query15->bindParam('max', $max);
        $query15->bindParam('min', $min); 
        $query15->execute();
        $results = $query15->fetchAll();
    # categorie + ville
    } elseif (empty($keywords) && !empty($categorie) && !empty($ville) && empty($min) && empty($max)) {
        $requete16 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE categorie LIKE '%$categorie%' AND ville LIKE '%$ville%'";
        $query16 = $pdo->prepare($requete16);       
        $query16->execute();
        $results = $query16->fetchAll();
    # ville + max
    }  elseif (empty($keywords) && empty($categorie) && !empty($ville) && empty($min) && !empty($max)) {
        $requete17 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE ville LIKE '%$ville%' AND prix <= :max";
        $query17 = $pdo->prepare($requete17);       
        $query17->bindParam('max', $max);
        $query17->execute();
        $results = $query17->fetchAll();
    # keywords + ville + min
    }  elseif (!empty($keywords) && empty($categorie) && !empty($ville) && !empty($min) && empty($max)) {
        $requete18 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE titre LIKE '%$keywords%' AND ville LIKE '%$ville%' AND prix >= :min";
        $query18 = $pdo->prepare($requete18);
        $query18->bindParam('min', $min);       
        $query18->execute();
        $results = $query18->fetchAll();
    # keywords + ville + max
    }  elseif (!empty($keywords) && empty($categorie) && !empty($ville) && empty($min) && !empty($max)) {
        $requete19 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE titre LIKE '%$keywords%' AND ville LIKE '%$ville%' AND prix <= :max";
        $query19 = $pdo->prepare($requete19);
        $query19->bindParam('max', $max);       
        $query19->execute();
        $results = $query19->fetchAll();
    }

?>

<html>

    <head>
        <title>Recherche personnalisée</title>
        <link href="style.css" rel="stylesheet">
    </head>

    <h1>Résultat(s) de la recherche</h1>

    <table>

        <thead>
            <tr>
                <th colspan="6"> Annonces </th>
            </tr>
            <tr>
                <th colspan="1"> Nom </th>
                <th colspan="1"> Prix </th>
                <th colspan="1"> Description </th>
                <th colspan="1"> Lieu </th>
                <th colspan="1"> Catégorie </th>
                <th colspan="1"> Date de création </th>
            </tr>
        </thead>
        <tbody>
            <?php 
            
            if (!empty($results)) {
                foreach ($results as $a) { ?>
                    <tr>
                    <?php foreach ($a as $value) { ?>
                        <td>
                        <?php echo $value ?>
                        </td>
                    <?php } ?>
                    </tr>
                <?php } 
            }      
            ?>
        </tbody>


    </table>

    <form action="recherche.php" method="post">
        <input type="submit" id='submit' value='Retour' ></input>
    </form>

</html>