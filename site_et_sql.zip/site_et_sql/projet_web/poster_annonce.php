<?php
    session_start();
    if (!isset($_SESSION['IS_CONNECTED'])) {
        header('Location: http://localhost:8080/projet_web/index.php');
        exit;
    }

    date_default_timezone_set('UTC');

    include 'pdo.php';

    if (isset($_POST['titre']) && isset($_POST['categorie']) && isset($_POST['ville']) && isset($_POST['prix']) && isset($_POST['description']) && isset($_FILES['file'])) {
        $email = $_SESSION['email'];
        $folder = $email;

        $info_fichier = $_FILES['file']['name'];

        if (!file_exists($folder)) {
            mkdir($folder);
        }



        $requete1 = "SELECT `AUTO_INCREMENT` FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'projet_web' AND TABLE_NAME = 'annonces'";
        $query1 = $pdo->prepare($requete1);
        $query1->execute();
        $id = $query1->fetchAll();

        $annoncedir = $folder."/".$id[0]['AUTO_INCREMENT']."/";

        if (!file_exists($annoncedir)) {
            mkdir($annoncedir);
        }

        $filename = str_replace(' ', '_', strtolower($info_fichier));

        if (!file_exists($folder.'/'.$id[0]['AUTO_INCREMENT'].'/'.$filename)) {
            move_uploaded_file($_FILES['file']['tmp_name'], $folder.'/'.$id[0]['AUTO_INCREMENT'].'/'.$filename);
        }

        $user = $_SESSION['ID'];
        $titre = $_POST['titre'];
        $prix = $_POST['prix'];
        $description = $_POST['description'];
        $date_de_publication = date("Y-m-d");
        $statut = 0;
        $ville = $_POST['ville'];
        $categorie = $_POST['categorie'];

        $requete2 = "INSERT INTO annonces(user, titre, prix, description, date_de_publication, statut, ville, categorie) VALUES (:user, :titre, :prix, :descriptio, :date_de_publication, :statut, :ville, :categorie)";
        $query2 = $pdo->prepare($requete2);
        $query2->bindParam('user', $user);
        $query2->bindParam('titre', $titre);
        $query2->bindParam('prix', $prix);
        $query2->bindParam('descriptio', $description);
        $query2->bindParam('date_de_publication', $date_de_publication);
        $query2->bindParam('statut', $statut);
        $query2->bindParam('ville', $ville);
        $query2->bindParam('categorie', $categorie);        
        $query2->execute();   

        header('Location: http://localhost:8080/projet_web/mes_annonces.php');
        exit;

    } else {
        header('Location: http://localhost:8080/projet_web/mes_annonces.php');
        exit;
    }

?>

