<?php
    session_start();
    if (!isset($_SESSION['IS_CONNECTED'])) {
        header('Location: http://localhost:8080/projet_web/index.php');
        exit;
    }

    $prenom = $_SESSION['prenom'];
    $nom = $_SESSION['nom'];
    $email = $_SESSION['email']


?>

<html>

    <head>
        <title>Mon_Compte</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css" media="screen" type="text/css" />
    </head>

    <h1> Mon compte </h1>

    <p> Nom = <?php echo $nom ?> <p>
    <p> Prénom = <?php echo $prenom ?> <p>
    <p> Email = <?php echo $email ?> <p>

    <h2> Changer de nom </h2>

    <form action="modifier_compte.php" method="post">
        <input type="text" name="nom" placeholder="Nouveau nom" />
        <button type="submit">Envoyer</button>
    </form>

    <h2> Changer de prénom </h2>

    <form action="modifier_compte.php" method="post">
        <input type="text" name="prenom" placeholder="Nouveau prénom" />
        <button type="submit">Envoyer</button>
    </form>

    <h2> Changer d'email </h2>

    <form action="modifier_compte.php" method="post">
        <input type="text" name="email" placeholder="Nouvel email" />
        <button type="submit">Envoyer</button>
    </form>

    <form style="margin-top: 30px;" action="home.php" method="post">
        <input type="submit" id='submit' value='Retour' ></input>
    </form>


</html>

