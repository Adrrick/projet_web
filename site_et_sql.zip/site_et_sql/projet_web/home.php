<?php
    session_start();
    if (!isset($_SESSION['IS_CONNECTED'])) {
        header('Location: http://localhost:8080/projet_web/index.php');
        exit;
    }

    $rang = $_SESSION['rang'];
    $nom = $_SESSION['nom'];
    $prenom = $_SESSION['prenom']

?>

<html>

    <head>
        <title>Home</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css" media="screen" type="text/css" />
    </head>
    <div id="container">
        <img src="images\lebondeal.png" alt="lebondeallogo" id='logo'>
        <h3> Bonjour <?php echo "$nom $prenom" ?>. </h3>

        <?php if ($rang == '1') { ?>
            
            <p> Rôle : Admin </p>

            <a href='gestion_users.php'> Gérer les utilisateurs </a> <br>

            <a href='gestion_annonces.php'> Gérer les annonces </a>

        <?php } else { ?>

            <h4> Rôle : Utilisateur </h4>
            <div id="bandeau">
                <form action="mes_annonces.php" method="post">
                    <input style="float: left ;margin-top: 15px; margin-left: 24px; width: 610px;";" type="submit" id='submit' value='Gérer mes annonces' ></input>
                </form>

                <form action="mon_compte.php" method="post">
                    <input style="float: left ;margin-top: 15px; width: 610px;" type="submit" id='submit' value='Gérer mon compte' ></input>
                </form>

                <form action="recherche.php" method="post">
                    <input style="float: left ;margin-top: 15px; width: 610px;" type="submit" id='submit' value='Rechercher une annonce' ></input>
                </form>
            </div>
        <?php } ?>
        <form action="deconnexion.php" method="post">
            <input style="background-color: #888870; margin-top: 30px;" type="submit" id='submit' value='Deconnexion' ></input>
        </form>
    </div>


</html>