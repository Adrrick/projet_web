<?php
    session_start();
    if (isset($_SESSION['IS_CONNECTED'])) {
        header('Location: http://localhost:8080/projet_web/home.php');
        exit;
    }
?>

<html>


    <head>
        <title>Login</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css" media="screen" type="text/css" />
    </head>

    <body>


        <h1>Identification</h1>
        <form action="connexion.php" method="post">
            <input type="text" name="email" placeholder="EMAIL" />
            <input type="password" name="mdp" placeholder="MOT DE PASSE" />
            <input type="submit" id='submit' value='Se connecter' ></input>
        </form>

        <form action="nouveau.php" method="post">
            <input type="submit" id='submit' value='Créer un compte' ></input>
        </form>

        <form action="index.php" method="post">
            <input type="submit" id='submit' value='Retour' ></input>
        </form>

    </body>


</html>