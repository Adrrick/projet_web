<?php
    session_start();
    if (isset($_SESSION['IS_CONNECTED'])) {
        header('Location: http://localhost:8080/projet_web/index.php');
        exit;
    }

?>

<html>
    <head>
        <title>Creation_compte</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css" media="screen" type="text/css" />
    </head>


    <h1>Créer un compte</h1>
        <form action="nouveau_bdd.php" method="post">
            <input type="text" name="nom" placeholder="NOM" />
            <input type="text" name="prenom" placeholder="PRENOM" />
            <input type="text" name="email" placeholder="EMAIL" />
            <input type="password" name="mdp" placeholder="MOT DE PASSE" />
            <input type="submit" id='submit' value='Créer un compte' ></input>
        </form>

        <form action="login.php" method="post">
            <input type="submit" id='submit' value='Retour' ></input>
        </form>


</html>