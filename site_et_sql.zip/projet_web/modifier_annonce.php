<?php
    session_start();
    if (!isset($_SESSION['IS_CONNECTED'])) {
        header('Location: http://localhost:8080/projet_web/index.php');
        exit;
    }

    include 'pdo.php';

    $id = $_SESSION['annonce_id'];

    if (empty($_POST['titre']) && empty($_POST['prix']) && empty($_POST['description']) && empty($_POST['ville']) && empty($_POST['categorie'])) {
        header('Location: http://localhost:8080/projet_web/mes_annonces.php');
        exit;
    }

    if ($_POST['titre']) {
        $titre = $_POST['titre'];
        $requete1 = "UPDATE annonces SET titre = :titre WHERE ID = $id";
        $query1 = $pdo->prepare($requete1);        
        $query1->bindParam('titre', $titre);
        $query1->execute();
    } elseif ($_POST['prix']) {
        $prix = $_POST['prix'];
        $requete2 = "UPDATE annonces SET prix = :prix WHERE ID = $id";
        $query2 = $pdo->prepare($requete2);        
        $query2->bindParam('prix', $prix);
        $query2->execute();            
    } elseif ($_POST['description']) {
        $description = $_POST['description'];
        $requete3 = "UPDATE annonces SET description = :description WHERE ID = $id";
        $query3 = $pdo->prepare($requete3);        
        $query3->bindParam('description', $description);
        $query3->execute();
    } elseif ($_POST['ville']) {
        $ville = $_POST['ville'];
        $requete4 = "UPDATE annonces SET ville = :ville WHERE ID = $id";
        $query4 = $pdo->prepare($requete4);        
        $query4->bindParam('ville', $ville);
        $query4->execute();
    } elseif ($_POST['categorie']) {
        $categorie = $_POST['categorie'];
        $requete5 = "UPDATE annonces SET categorie = :categorie WHERE ID = $id";
        $query5 = $pdo->prepare($requete5);        
        $query5->bindParam('categorie', $categorie);
        $query5->execute();
    }

    unset($_SESSION['annonce_id']);
    header('Location: http://localhost:8080/projet_web/mes_annonces.php');
    exit;
?>