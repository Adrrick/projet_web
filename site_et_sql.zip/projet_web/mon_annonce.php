<?php
    session_start();
    if (!isset($_SESSION['IS_CONNECTED'])) {
        header('Location: http://localhost:8080/projet_web/index.php');
        exit;
    }

    include 'pdo.php';

    $id = $_POST['ID'];
    $_SESSION['annonce_id'] = $id;

    $requete1 = "SELECT titre, prix, description, ville, categorie FROM annonces WHERE ID=$id";
    $query1 = $pdo->prepare($requete1);    
    $query1->execute();
    $results = $query1->fetchAll();

    $titre = $results[0]['titre'];
    $prix = $results[0]['prix'];
    $description = $results[0]['description'];
    $ville = $results[0]['ville'];
    $categorie = $results[0]['categorie'];

?>

<html>

    <head>
    
        <link rel="stylesheet" type="text/css" href="style.css">
        <title> Modifier une annonce </title>
    
    </head>

    <h1> Mon annonce </h1>

    <p> Titre = <?php echo $titre ?> <p>
    <p> Prix = <?php echo $prix ?> € <p>
    <p> Description = <?php echo $description ?> <p>
    <p> Ville = <?php echo $ville ?> <p>
    <p> Catégorie = <?php echo $categorie ?> <p>

    <h2> Changer de titre </h2>

    <form action="modifier_annonce.php" method="post">
        <input type="text" name="titre" placeholder="Nouveau titre" />
        <button type="submit">Envoyer</button>
    </form>

    <h2> Changer de prix </h2>

    <form action="modifier_annonce.php" method="post">
        <input type="number" name="prix" placeholder="Nouveau prix" />
        <button type="submit">Envoyer</button>
    </form>

    <h2> Changer de description </h2>

    <form action="modifier_annonce.php" method="post">
        <input type="text" name="description" placeholder="Nouvelle description" />
        <button type="submit">Envoyer</button>
    </form>

    <h2> Changer de ville </h2>

    <form action="modifier_annonce.php" method="post">
        <input type="text" name="ville" placeholder="Nouvelle ville" />
        <button type="submit">Envoyer</button>
    </form>

    <h2> Changer de catégorie </h2>

    <form action="modifier_annonce.php" method="post">
        <input type="text" name="categorie" placeholder="Nouvelle catégorie" />
        <button type="submit">Envoyer</button>
    </form>

    <form style="margin-top: 30px;" action="mes_annonces.php" method="post">
        <input type="submit" id='submit' value='Retour' ></input>
    </form>









</html>