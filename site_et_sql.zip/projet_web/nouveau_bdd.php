<?php
    session_start();
    if (isset($_SESSION['IS_CONNECTED'])) {
        header('Location: http://localhost:8080/projet_web/index.php');
        exit;
    }

    include 'pdo.php';

    $nom = htmlspecialchars($_POST['nom']);
    $prenom = htmlspecialchars($_POST['prenom']);
    $email = htmlspecialchars($_POST['email']);
    $mdp = htmlspecialchars($_POST['mdp']);

    if (empty($nom) || empty($prenom) || empty($mdp) || empty($email) || strpos($email, '@') == False || strpos($email, '.') == False) {
        header('Location: http://localhost:8080/projet_web/nouveau.php');
        exit;
    }

    $requete1 = "SELECT * FROM users WHERE email LIKE :email";
    $query1 = $pdo->prepare($requete1);
    $query1->bindParam('email', $email);
    $query1->execute();
    $user = $query1->fetchAll();

    if (empty($user)) {
        $rang = 2;
        $requete2 = "INSERT INTO users(nom, prenom, email, mdp, rang) VALUES (:nom, :prenom, :email, :mdp, :rang)";
        $query2 = $pdo->prepare($requete2);
        $query2->bindParam('nom', $nom);            
        $query2->bindParam('prenom', $prenom);
        $query2->bindParam('email', $email);
        $query2->bindParam('mdp', $mdp);
        $query2->bindParam('rang', $rang);
        $query2->execute();
        header('Location: http://localhost:8080/projet_web/index.php');
        exit;
    } else {
        header('Location: http://localhost:8080/projet_web/index.php');
        exit;
    }
?>