<?php

    include 'pdo.php';

    $requete1 = "SELECT titre, prix, description, ville, categorie, date_de_publication FROM annonces";
    $query1 = $pdo->prepare($requete1);    
    $query1->execute();
    $results = $query1->fetchAll();

?>

<html>

    <head>
        <title>Recherche</title>
        <link href="style.css" rel="stylesheet">
    </head>

    <h1>Rechercher une annonce</h1>

    <form action="search.php" method="post">
        <input type="text" name="keywords" placeholder="Mots clés (nom de l'offre)" />
        <input type="text" name="categorie" placeholder="Catégorie" />
        <input type="text" name="ville" placeholder="Lieu de l'offre (ville)" />
        <br>
        <input type="number" name="min" placeholder="Prix minimal" />
        <br>
        <input type="number" name="max" placeholder="Prix maximal" />
        <br>
        <button type="submit">Envoyer</button>
    </form>

    <form style="margin-top: 30px;" action="home.php" method="post">
        <input type="submit" id='submit' value='Retour' ></input>
    </form>


    <h2> Toutes les annonces </h2>

    <table>

        <thead>
            <tr>
                <th colspan="6"> Annonces </th>
            </tr>
            <tr>
                <th colspan="1"> Nom </th>
                <th colspan="1"> Prix </th>
                <th colspan="1"> Description </th>
                <th colspan="1"> Lieu </th>
                <th colspan="1"> Catégorie </th>
                <th colspan="1"> Date de création </th>
            </tr>
        </thead>
        <tbody>
            <?php 
            
                foreach ($results as $a) { ?>
                    <tr>
                    <?php foreach ($a as $value) { ?>
                        <td>
                        <?php echo $value ?>
                        </td>
                    <?php } ?>
                    </tr>
                <?php }              

            ?>
        </tbody>


    </table>


</html>