<?php
    session_start();
    if (!isset($_SESSION['IS_CONNECTED'])) {
        header('Location: http://localhost:8080/projet_web/index.php');
        exit;
    }

    include 'pdo.php';

    $id = (int)$_SESSION['ID'];

    $requete1 = "SELECT ID, titre, prix, description, ville, categorie, date_de_publication FROM annonces WHERE user=$id";
    $query1 = $pdo->prepare($requete1);    
    $query1->execute();
    $results = $query1->fetchAll();

?>

<html>

    <head>
        <title> Mes annonces </title>
        <link href="style.css" rel="stylesheet">
    </head>

    <h1> Mes annonces </h1>

    <h2> Créer une annonce </h2>

    <p> (Vous devez remplir tous les champs) <p>

    <form enctype="multipart/form-data" action="poster_annonce.php" method="post">
        <input type="text" name="titre" placeholder="Titre" />
        <input type="text" name="categorie" placeholder="Catégorie" />
        <input type="text" name="ville" placeholder="Lieu de l'offre (ville)" />
        <br>
        <input type="number" name="prix" placeholder="Prix en €" />
        <br>
        <input type="text" name="description" placeholder="Description" />
        <br>
        <label for="file"> Choisir une image : </label>
        <input type="file" name="file">
        <button type="submit">Envoyer</button>
    </form>

    <br>

    <table>

        <thead>
            <tr>
                <th colspan="7"> Annonces </th>
            </tr>
            <tr>
                <th colspan="1"> ID </th>
                <th colspan="1"> Nom </th>
                <th colspan="1"> Prix </th>
                <th colspan="1"> Description </th>
                <th colspan="1"> Ville </th>
                <th colspan="1"> Catégorie </th>
                <th colspan="1"> Date de création </th>
            </tr>
        </thead>
        <tbody>
            <?php 
            
                foreach ($results as $a) { ?>
                    <tr>
                    <?php foreach ($a as $value) { ?>
                        <td>
                        <?php echo $value ?>
                        </td>
                    <?php } ?>
                    </tr>
                <?php }              

            ?>
        </tbody>


    </table>

    <h2> Modifier une annonce </h2>

    <form action="mon_annonce.php" method="post">
        <input type="number" name="ID" placeholder="ID de l'annonce à modifier" />
        <button type="submit">Modifier cette annonce</button>
    </form>

    <form style="margin-top: 30px;" action="home.php" method="post">
        <input type="submit" id='submit' value='Retour' ></input>
    </form>

</html>