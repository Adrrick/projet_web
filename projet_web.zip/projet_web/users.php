<?php

    session_start();

    if ($_SESSION['rank'] != '1') {
        header('Location: http://localhost:8080/projet_web/home.php');
        exit;
    }

    include 'pdo.php';

    $requete1 = "SELECT * FROM users WHERE user_name NOT LIKE 'admin' ORDER BY user_rank, user_id";
    $query1 = $pdo->prepare($requete1);
    $query1->execute();
    $users = $query1->fetchAll();
?>

<html>

    <head>
    
        <link rel="stylesheet" type="text/css" href="style.css">
    
    </head>

    <body>


        <table>

            <thead>
                <tr>
                    <th colspan="4"> Utilisateurs </th>
                </tr>
                <tr>
                    <th colspan="1"> user_id </th>
                    <th colspan="1"> user_rank </th>
                    <th colspan="1"> user_name </th>
                    <th colspan="1"> user_email </th>
                </tr>
            </thead>
            <tbody>
                <?php 
                
                    foreach ($users as $a) { ?>
                        <tr>
                        <?php foreach ($a as $value) { ?>
                            <td>
                            <?php echo $value ?>
                            </td>
                        <?php } ?>
                        </tr>
                    <?php }              

                ?>
            </tbody>


        </table>

        <h1>Supprimer un utilisateur</h1>
        <form action="delete_user.php" method="post">
            <input type="text" name="nom" placeholder="NOM" />
            <input type="text" name="email" placeholder="EMAIL" />
            <button type="submit">Supprimer ?</button>
        </form>

        <a href="home.php"> Retour </a>


    </body>

</html>

