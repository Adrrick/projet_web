<?php
    session_start();
    if (isset($_SESSION['IS_CONNECTED'])) {
        header('Location: http://localhost:8080/projet_web/home.php');
        exit;
    }
?>

<html>


    <head>
        <title>Index</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css" media="screen" type="text/css" />
    </head>

    <body>
        <div id="container">
            <form style="float: left;" action="login.php" method="post">
                <input type="submit" id='submit' value='Se connecter' ></input>
            </form>
            <form style="float: left;" action="nouveau.php" method="post">
                <input type="submit" id='submit' value='Créer un compte' ></input>
            </form>
            <form style="float: left;" action="poster_annonce.php" method="post">
                <input type="submit" id='submit' value='Poster une annonce' ></input>
            </form>

            <img src="images\lebondeal.png" alt="lebondeallogo" id='logo'>


            
        </div>
        <div id="bandeau">
            <form style="margin-left: 33%;" action="recherche.php" method="post">
                <input style="margin-top: 15px;" type="submit" id='submit' value='Faire une recherche' ></input>
            </form>
        </div>
    </body>


</html>