<?php
    session_start();
    if (!isset($_SESSION['IS_CONNECTED'])) {
        header('Location: http://localhost:8080/projet_web/index.php');
        exit;
    }

    include 'pdo.php';

    if (empty($_POST['nom']) && empty($_POST['prenom']) && empty($_POST['email'])) {
        header('Location: http://localhost:8080/projet_web/mon_compte.php');
        exit;
    }

    $email = $_SESSION['email'];
    if ($_POST['nom']) {
        $nom = $_POST['nom'];
        $requete2 = "UPDATE users SET nom = :nom WHERE email LIKE :email";
        $query2 = $pdo->prepare($requete2);        
        $query2->bindParam('nom', $nom);
        $query2->bindParam('email', $email);
        $query2->execute();
        $_SESSION['nom'] = $nom;
    } elseif ($_POST['prenom']) {
        $prenom = $_POST['prenom'];
        $requete3 = "UPDATE users SET prenom = :prenom WHERE email LIKE :email";
        $query3 = $pdo->prepare($requete3);        
        $query3->bindParam('prenom', $prenom);
        $query3->bindParam('email', $email);
        $query3->execute();
        $_SESSION['prenom'] = $prenom;
    } elseif ($_POST['email']) {
        $new_email = $_POST['email'];
        $requete1 = "SELECT * FROM users WHERE email LIKE :email";
        $query1 = $pdo->prepare($requete1);
        $query1->bindParam('email', $new_email);
        $query1->execute();
        $liste_users = $query1->fetchAll();
        if (!empty($liste_users) || strpos($new_email, '@') == False || strpos($new_email, '.') == False) {
            header('Location: http://localhost:8080/projet_web/mon_compte.php');
            exit;            
        } else {
            $requete4 = "UPDATE users SET email = :new_email WHERE email LIKE :email";
            $query4 = $pdo->prepare($requete4);        
            $query4->bindParam('new_email', $new_email);
            $query4->bindParam('email', $email);
            $query4->execute();
            $_SESSION['email'] = $new_email;
        }
    }

    header('Location: http://localhost:8080/projet_web/mon_compte.php');
    exit;
?>