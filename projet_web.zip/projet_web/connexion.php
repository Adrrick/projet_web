<?php

session_start();
include 'pdo.php';

if (isset($_SESSION['IS_CONNECTED'])) {
    header('Location: http://localhost:8080/projet_web/home.php');
    exit;
}

$_SESSION['email'] = htmlspecialchars($_POST['email']);
$_SESSION['mdp'] = htmlspecialchars($_POST['mdp']);

if (empty($_SESSION['email']) || empty($_SESSION['mdp'])) {   
    header('Location: http://localhost:8080/projet_web/login.php');
    exit; 
} else {
    $email = htmlspecialchars($_POST['email']);
    $mdp = htmlspecialchars($_POST['mdp']);
    $requete1 = "SELECT * FROM users WHERE email LIKE :email AND mdp LIKE :mdp";
    $query1 = $pdo->prepare($requete1);
    $query1->bindParam('email', $email);
    $query1->bindParam('mdp', $mdp);
    $query1->execute();
    $liste_users = $query1->fetchAll();
    if (empty($liste_users)) {
        header('Location: http://localhost:8080/projet_web/login.php');
        exit;
    } else {
        $_SESSION['IS_CONNECTED'] = true;
        $_SESSION['rang'] = $liste_users[0]['rang'];
        $_SESSION['ID'] = $liste_users[0]['ID'];
        $_SESSION['nom'] = $liste_users[0]['nom'];
        $_SESSION['email'] = $liste_users[0]['email'];
        $_SESSION['prenom'] = $liste_users[0]['prenom'];
        header('Location: http://localhost:8080/projet_web/home.php');
        exit;
    }
}

?>